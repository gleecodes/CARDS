﻿using System;


namespace deckofcards
{
    class Program
    {
        static void Main(string[] args)
        {
            Deck newDeck = new Deck ();
            System.Console.WriteLine(newDeck);
            Player Gina = new Player("Gina");
            Player Katelin = new Player("Katelin");
            Player Eirika = new Player("Eirika");
            newDeck.shuffle();
            Eirika.Draw(newDeck);
            Eirika.Draw(newDeck);
            Katelin.Draw(newDeck);
            Katelin.Draw(newDeck);
            Gina.Draw(newDeck);
            Gina.Draw(newDeck);

            

        }
    }
}
